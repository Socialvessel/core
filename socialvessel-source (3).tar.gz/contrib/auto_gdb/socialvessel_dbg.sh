#!/bin/bash
# use testnet settings,  if you need mainnet,  use ~/.socialvesselcore/socialvesseld.pid file instead
socialvessel_pid=$(<~/.socialvesselcore/testnet3/socialvesseld.pid)
sudo gdb -batch -ex "source debug.gdb" socialvesseld ${socialvessel_pid}
