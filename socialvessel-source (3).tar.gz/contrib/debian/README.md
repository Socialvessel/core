
Debian
====================
This directory contains files used to package socialvesseld/socialvessel-qt
for Debian-based Linux systems. If you compile socialvesseld/socialvessel-qt yourself, there are some useful files here.

## socialvessel: URI support ##


socialvessel-qt.desktop  (Gnome / Open Desktop)
To install:

	sudo desktop-file-install socialvessel-qt.desktop
	sudo update-desktop-database

If you build yourself, you will either need to modify the paths in
the .desktop file or copy or symlink your socialvessel-qt binary to `/usr/bin`
and the `../../share/pixmaps/socialvessel128.png` to `/usr/share/pixmaps`

socialvessel-qt.protocol (KDE)

