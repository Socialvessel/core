Sample configuration files for:

SystemD: socialvesseld.service
Upstart: socialvesseld.conf
OpenRC:  socialvesseld.openrc
         socialvesseld.openrcconf
CentOS:  socialvesseld.init
OS X:    org.socialvessel.socialvesseld.plist

have been made available to assist packagers in creating node packages here.

See doc/init.md for more information.
